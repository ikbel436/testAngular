import { Injectable } from '@angular/core';
import { Video } from '../Model/Video';

@Injectable({
  providedIn: 'root'
})
export class VideoService {

  constructor() { }
  listVieo = [
    { id: 1 , title: 'video1' , genre: "educatif" , public: false , nbrShared:0 } , 
    { id: 2 , title: 'video2' , genre: "educatif" , public: false , nbrShared:300 } , 
    { id: 3 , title: 'video1' , genre: "educatif" , public: true , nbrShared:450 } , 

  ]
  add(product:Video){
    this.listVieo.push(product);
  
  }
}
