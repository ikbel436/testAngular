export class Video{
    id!: number
title !: string ;
genre !: string;
public !: boolean;
nbrShared !: number;
}