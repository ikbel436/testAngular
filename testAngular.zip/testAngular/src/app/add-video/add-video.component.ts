import { Component, OnInit } from '@angular/core';
import { VideoService } from '../service/video.service';
import { Video } from '../Model/Video';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-video',
  templateUrl: './add-video.component.html',
  styleUrls: ['./add-video.component.css']
})
export class AddVideoComponent implements OnInit {
  product! : Video;
  constructor(private sv:VideoService,private route:Router) { }

  ngOnInit(): void {
    this.product=new Video;
  }
  onsubmit(){
    this.sv.add(this.product)

this.route.navigateByUrl('/videos')
  }

}
