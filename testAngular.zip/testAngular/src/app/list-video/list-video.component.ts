import { Component, OnInit } from '@angular/core';
import { Video } from '../Model/Video';
import { VideoService } from '../service/video.service';

@Component({
  selector: 'app-list-video',
  templateUrl: './list-video.component.html',
  styleUrls: ['./list-video.component.css']
})
export class ListVideoComponent implements OnInit {
  listProduct!: Video[] ;
  constructor(private ps:VideoService) { }

  ngOnInit(): void {
    this.listProduct= this.ps.listVieo;
  }
  editVideo(video: Video) {
    // code pour modifier la vidéo sélectionnée
  }
  shareVideo(video: Video) {
    video.nbrShared++;
    
  }
}
