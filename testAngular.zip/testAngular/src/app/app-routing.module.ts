import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListVideoComponent } from './list-video/list-video.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { AddVideoComponent } from './add-video/add-video.component';


const routes: Routes = [
  {path: '' , redirectTo:'videos' , pathMatch:'full'} ,
  {path: 'videos' , component: ListVideoComponent } ,
  {path :'navBar', component: NavBarComponent},
  {path:'add',component: AddVideoComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
